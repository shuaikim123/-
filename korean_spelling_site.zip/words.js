const words = ["안녕하세요", "사랑", "행복", "학교", "친구"];
let currentWord = "";
