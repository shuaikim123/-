function nextWord() {
  const index = Math.floor(Math.random() * words.length);
  currentWord = words[index];
  document.getElementById("word-display").textContent = currentWord;
  document.getElementById("input-word").value = "";
  document.getElementById("feedback").textContent = "";
}

function checkSpelling() {
  const userInput = document.getElementById("input-word").value.trim();
  const feedback = document.getElementById("feedback");
  if (userInput === currentWord) {
    feedback.textContent = "✅ 正确！";
    feedback.style.color = "green";
  } else {
    feedback.textContent = `❌ 错误，正确拼写是：${currentWord}`;
    feedback.style.color = "red";
  }
}
